%% Demo of Diskmap_SEM
%  Demo of stretch energy minimization for disk-type equiareal parameterization.
%  Please refer to [1] for more details.
%  [1] M.-H. Yueh, W.-W. Lin, C.-T. Wu, and S.-T. Yau, A Novel Stretch 
%      Energy Minimization Algorithm for Equiareal Parameterizations, 
%      mathscidoc:1708.09001, 2017.
%
%  Syntax
%   uv = Diskmap_SEM(F,V)
%
%  Descriptions
%  F  : double array, nf x 3, faces of mesh
%  V  : double array, nv x 3, vertices of mesh
%%
clear;clc;close all;


%% Model 1
filename = 'Chinese_Lion';
load([filename '.mat']);
fprintf(['Model Name        : ' filename '\n']);
fprintf( 'Number of vertices: %6d\n', size(F,1));
fprintf( 'Number of faces   : %6d\n', size(V,1));
tic;
uv = Diskmap_SEM(F,V); % Disk map via conformal energy minimization
fprintf( 'Time cost         : %1.4f seconds\n\n', toc);
displayPara(F, V, uv); % Display parameterization result
pause(0.01);


%% Model 2
filename = 'Human_Brain';
load([filename '.mat']);
fprintf(['Model Name        : ' filename '\n']);
fprintf( 'Number of vertices: %6d\n', size(F,1));
fprintf( 'Number of faces   : %6d\n', size(V,1));
tic;
uv = Diskmap_SEM(F,V); % Disk map via conformal energy minimization
fprintf( 'Time cost         : %1.4f seconds\n\n', toc);
displayPara(F, V, uv); % Display parameterization result

