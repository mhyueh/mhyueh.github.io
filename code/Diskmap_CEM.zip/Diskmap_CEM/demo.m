%% Demo of Diskmap_CEM
%  Demo of conformal energy minimization for disk-type conformal parameterization.
%  Please refer to [1] for more details.
%  [1] M.-H. Yueh, W.-W. Lin, C.-T. Wu, and S.-T. Yau, 
%      An efficient energy minimization for conformal parameterizations, 
%      iccm.archive:1608.09013, 2016.
%
%  Syntax
%   uv = Diskmap_CEM(F,V)
%
%  Descriptions
%  F  : double array, nf x 3, faces of mesh
%  V  : double array, nv x 3, vertices of mesh
%%
clear;clc;close all;

filename = {'cyho_neutral'; 'sliu_pout'};

for ii = 1:length(filename)
    load([filename{ii} '.mat']);
    fprintf(['Model Name        : ' filename{ii} '\n']);
    fprintf( 'Number of vertices: %6d\n', size(V,1));
    fprintf( 'Number of faces   : %6d\n', size(F,1));
    tic;
    % Disk map via conformal energy minimization
    uv = Diskmap_CEM(F,V);
    fprintf( 'Time cost         : %1.4f seconds\n\n', toc);
    % Display parameterization result
    % The color means the scaled mean curvature
    displayPara(F, V, uv);
    pause(0.01);
end

